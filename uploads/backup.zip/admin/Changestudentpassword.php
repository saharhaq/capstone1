<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Create profile</title>
</head>
<body>
  <h2>Profile</h2>

<?php

session_start();

if (empty($_SESSION['ProfessorID'])) {
	echo '<p>Please log in to continue</p>';
	echo '<a href="index.html">Login here</a>';
 }
 else {
  
  $dbc = mysqli_connect('localhost', 'root', 'Capstone', 'NursingHours')
    or die('Error connecting to MySQL server.');

  echo '<p> reset student password</p>';
  echo '<form method="post" action="changestudentpass_2.php">';
  echo '<label for="studentID">Student ID : </label>';
  echo '<input type="text" name="studentID" /><br />';
  echo '<label for="password">New Password : </label>';
  echo '<input type="password" name="password" /><br />';
  echo '<input type="submit" value="Reset student password" name="submit" />';
  echo '</form>';
  
  }
  
?>

</body>
</html>
