<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>RN to BSN Student Profile</title>
</head>
<body>
  <h2>Welcome</h2>

  <p>RN to BSN Admin Profile</p>

 
  <br />
 <form method="post" action="addstudent.php">
    <label for="StudentId">Please type in new student ID:</label>
    <input type="text" name="StudentId" /><br />
	
	<label for="Firstname">Please type in new First Name :</label>
    <input type="text" name="Firstname" /><br />
	
	<label for="Lastname">Please type in new Last Name:</label>
    <input type="text" name="Lastname" /><br />
	
	<label for="courseReference">Please type in Student's course reference number:</label>
    <input type="text" name="courseReference" /><br />
	
    <input type="submit" value="Create new Student" name="submit" />
  </form>

 

<div align="center"><img src="background.jpg" class="bg"></div>  
</body>
</html>