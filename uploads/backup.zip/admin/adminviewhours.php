<?php
session_start();

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title></title>

  <script>
function myFunction()
{
var r=confirm("Are you sure you want to delete?\nPress OK to continue...");
if (r==true)
  {
    return true;
  }else return false;
}
</script>
  <script type="javascript/txt">
	function showSIDinput()
	{
		document.getElementById("mylabel").innerHTML="Student ID: ";
		document.getElementById("myinput").type="text";
	}
	
	function showREFinput()
	{
		document.getElementById("mylabel").innerHTML="Reference #: ";
		document.getElementById("myinput").type="text";
	}
  </script>
</head>
<body>


<?php
if(!isset($_SESSION['ProfessorID']))
{
echo "<a href='index.html'>Log in</a>"; 
die("click link to login");
}
?>

 <form  method="get" action="adminviewhours.php">
 <input type="hidden" name="TLD" value="<?php echo $_GET['TLD']; ?>"/>
 <select name="admin"> 

<option  value="select">Select</option>
		<option value = "All">View All</option>
		<option value = "ID" onclick="showSIDinput();">Student Id</option>
		<option value = "REF" onclick="showREFinput();">Reference #</option>
</select>


<!--Input box--->

 <label for="search"id="mylabel"></label>
	<input type="text" name="search"id="myinput"/><br />

	
<input  name="submit" type="submit" value="Submit" />	
	
	
</form>




<?php

	if ( ! empty($_GET["admin"]))
	{

    $dbc = mysqli_connect('localhost', 'root', 'Capstone', 'NursingHours')
        or die(mysqli_connect_error());
     
	$search = mysqli_real_escape_string($dbc, strip_tags ($_GET['admin']));
	$number= mysqli_real_escape_string($dbc, strip_tags ($_GET['search']));
		
	echo'<form  method="post" action="changehours.php"> <table>
<tr>
<th>Hours</th>
<th>Activity</th>
<th>Description</th>
<th>Approval</th>
<th>Delete</th>
</tr>';
	if($search == "All")	
	{

	$sql = " SELECT id, Hours,Activity,Description,Approval FROM Hours WHERE `Class code` = '".$_GET['TLD']."';";
	$sql2 = " SELECT SUM(Hours) AS Hours FROM Hours where `Class code` = '".$_GET['TLD']."' AND Approval='Approved'";


	}
	else if($search == "ID")	
	{
	
	$sql = " SELECT id, Hours,Activity,Description,Approval FROM Hours  WHERE `studentid` = '".$number."';";
	$sql2 = " SELECT SUM(Hours) AS Hours FROM Hours where `studentid` = '".$number."' AND Approval='Approved'";

	}
	else if($search == "REF")	
	{
		$sql = "SELECT id, Hours,Activity,Description,Approval FROM Hours ".
		" INNER JOIN Students ON Hours.StudentID = Students.StudentID ".
		" WHERE Students.courseReference = '".$number."';";
		
		$sql2 = " SELECT SUM(Hours) AS Hours FROM Hours ".
		" INNER JOIN Students ON Hours.StudentID = Students.StudentID ".
		" WHERE Students.courseReference = '".$number."' AND Approval='Approved'";
	}
	
		//echo $sql;
	
	// execute the query
	$result = mysqli_query($dbc, $sql)
		or die("Could not fetch data: " . mysqli_error($dbc));
	
	while ( $row = mysqli_fetch_assoc($result) ) {
		echo "<tr>\n";
		foreach($row as $key => $value) {
			if($key != "id" && $key != "Approval")
			{
				echo "<td>", $value, "</td>\n";
			}
			if($key == "Approval")
			{
				echo '<td>';
				echo '<select name="'.$row['id'].'"> 
					<option  value="Pending">Pending</option>
					<option value = "Approved">Approved</option>
					<option value = "Disapproved" >Disapproved</option>
				</select>';
				echo '</td>';
			}
		}
		echo ' <td><a href="hoursdelete.php?id='.$row['id'].'"onclick="return myFunction();"><img width="25" height="25" alt="" src="trash.png"></a></td>';
		echo "</tr>\n";
	}
	
	$result = mysqli_query($dbc, $sql2)
		or die("Could not fetch data: " . mysqli_error($dbc));
		
	$row = mysqli_fetch_assoc($result);
	echo '<tr><th colspan="4" align="left">';
	echo 'Total Approved hours:'.$row['Hours'];
	echo'</th></tr>';
	echo '</table>';
	echo '<input  type="submit" value="Change approval status" />	';
	echo '</form>';
	// close the database connection
	mysqli_close($dbc);
}	
?>	


</body>
</html>