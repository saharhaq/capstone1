<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Select Hours Type</title>
</head>
<body>
  <h2>Select & enter Hours</h2>

<?php

  $dbc = mysqli_connect('localhost', 'root', '', 'NursingHours')
    or die('Error connecting to MySQL server.');

  $query = "select seminar_id,seminar_name,seminar_date from seminars";

  $result = mysqli_query($dbc, $query)
    or die('Error querying database.');
  
  $options="";

echo '<form method="post" action="confirmhours.php">';
echo "<select name=seminar_id>";
while ($row=mysqli_fetch_array($result)) { 

    $seminar_id=$row["seminar_id"]; 
    $seminar_name=$row["seminar_name"]; 
    $seminar_date=$row["seminar_date"]; 	
    $options="<OPTION VALUE=\"$seminar_id\">". $seminar_id ." ". $seminar_name ." ". $seminar_date ;
echo $options;	
} 
echo "</select> <br/>";
echo '<input type="submit" value="submit" name="submit" /><br/>';
echo '</form>';
mysqli_close($dbc);
?>

<div align="center"><img src="background.jpg" class="bg"></div>
</body>
</html>
